package br.sc.senac.perfil.view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SystemView extends JFrame {
    JPanel pnlSystemView = new JPanel();
    JMenuBar menuBar = new JMenuBar();


    public SystemView() {

        initComponents();
         initMenuBar();
        // listener();
    }

    public void initComponents() {
        setTitle("Tela de Menu");
        setSize(1280, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(pnlSystemView);
        setVisible(true);
        pnlSystemView.setLayout(null);
        setJMenuBar(menuBar);
    }


    public void initMenuBar() {
        JMenu cadastrarPessoaMenu = new JMenu("Cadastrar");
        JMenu fazerTesteMenu = new JMenu("Fazer teste");
        JMenu sairMenu = new JMenu("Sair");

        //cadastrar pessoa
        //fazer o teste
        JMenuItem cadastrarItem = new JMenuItem("Cadastrar");
        JMenuItem fazerItem = new JMenuItem("Fazer teste");
        JMenuItem sairItem = new JMenuItem("Sair");

        cadastrarPessoaMenu.add(cadastrarItem);
        fazerTesteMenu.add(fazerItem);
        sairMenu.add(sairItem);


        menuBar.add(cadastrarItem);
        menuBar.add(fazerItem);
        menuBar.add(sairMenu);

        cadastrarItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PerfilView();
                dispose();
            }
        });

        fazerItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new QuestionarioView();
                dispose();
            }
        });
        sairItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String msg = "Deseja sair do sistema?";
                int opcaoEscolhida = JOptionPane.showConfirmDialog(null, msg, "Menu", JOptionPane.YES_NO_OPTION);
                if (opcaoEscolhida == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }

            }
        });
    }

    public void listener() {

        ImageIcon addUser = new ImageIcon("C:\\Users\\vagner.berger\\Downloads\\mcap (2)\\mcap\\src\\br\\sc\\senac\\mcap\\img\\user.png");
        JButton btnCadastrar = new JButton("Cliente", addUser);
        btnCadastrar.setBounds(450, 300, 150, 100);
        pnlSystemView.add(btnCadastrar);

        btnFazerTeste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PerfilView PerfilView = new PerfilView();
                dispose();
            }
        });
        ImageIcon searchUser = new ImageIcon("C:\\Users\\vagner.berger\\Downloads\\mcap (2)\\mcap\\src\\br\\sc\\senac\\mcap\\img\\pesquisar.png");
        JButton btnPesquisar = new JButton("Pesquisar", searchUser);
        btnPesquisar.setBounds(650, 300, 150, 100);
        pnlSystemView.add(btnPesquisar);

        btnCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                QuestionarioView  QuestionarioView = new  QuestionarioView();
                dispose();
            }
        });
    }



}